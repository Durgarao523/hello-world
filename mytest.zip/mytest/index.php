<?php
	// $some=array("Volvo", "BMW", "Toyota");
	
	/*for ($i=0; $i <count($some); $i++) { 
		# code...
		echo $some[$i];
	}*/

	// $name = $_POST['fname'];
// 	$myObj;
// $myObj->name = "John";
// $myObj->age = 30;
// $myObj->city = "New York";
// $myObj->data=$some;

// $myJSON = json_encode($myObj);

// echo $myJSON;
	// echo $name;
/*$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");

echo $age;*/

	
	// function myfun(){
	// 	static $x=5;
		
	// 	echo $x;
	// 	$x++;
	// }
	// myfun();
	// myfun();
	// myfun();

/*	$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "CREATE DATABASE myDB";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();*/


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS MyGuests (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, firstname VARCHAR(30) NOT NULL,lastname VARCHAR(30) NOT NULL,email VARCHAR(50),reg_date TIMESTAMP)";

if ($conn->query($sql) === TRUE) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


if($_SERVER['REQUEST_METHOD']=="GET"){
	$sql = "SELECT * FROM MyGuests";
$result = $conn->query($sql);
$obj=new stdClass();
$obj->status="success";
if ($result->num_rows > 0) {
    // output data of each row

    $a=array();
    while($row = $result->fetch_assoc()) {
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
        array_push($a,$row);
      
    }
$obj->data=$a;
    echo json_encode($obj);
} else {
    echo "0 results";
}

$conn->close();
}

if($_SERVER['REQUEST_METHOD']=="POST"){



/**for file upload ******/
/*$target_dir = "uploads/";

$target_file = $target_dir . basename($_FILES["file"]["name"]);

$uploadOk = 1;

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

$check = getimagesize($_FILES["file"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }


    if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
		}


		 if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }*/

/**end upload ***********/

/**send mail *********/

$to = "durgarao.iton@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <durgarao.m@iton.com>' . "\r\n";

mail($to,$subject,$txt,$headers);


/**end mail **********/





/*$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];



$stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $fname, $lname, $email);


$stmt->execute();


if($stmt->error){
	echo $stmt->error;
}else{
	
	$obj=new stdClass();
	$obj->status="success";
	$obj->message="data saved successfully";
    echo json_encode($obj);
}*/

}//post


if($_SERVER['REQUEST_METHOD']=='DELETE'){

$id=$_GET['id'];

$sql = "DELETE FROM MyGuests WHERE id=$id";
$result = $conn->query($sql);

if($result==true){
	$obj=new stdClass();
	$obj->status="success";
	$obj->message="record Deleted successfully";

	echo json_encode($obj);

}
else{
	$obj=new stdClass();
	$obj->status="failed";
	$obj->message="Failed to delete";
	echo json_encode($obj);
}

}//Delete


if($_SERVER['REQUEST_METHOD']=='PUT'){

parse_str(file_get_contents("php://input"),$post_vars);
    $id=$post_vars['id'];
    $fname=$post_vars['fname'];
    $lname=$post_vars['lname'];
    $email=$post_vars['email'];


$stmt = $conn->prepare("UPDATE MyGuests SET firstname=?,lastname=?,email=? WHERE id=?");
$stmt->bind_param("sssd", $fname, $lname, $email,$id);


$stmt->execute();

if($stmt->error){
	echo $stmt->error;
}
else{
	$obj=new stdClass();
	$obj->status="success";
	$obj->message="record updated successfully";
	echo json_encode($obj);
}

}//put






	
	
?>

